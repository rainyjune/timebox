package com.webbookstore.service;

import com.webbookstore.bean.Orders;

public interface OrderService {
	/**
	 * 保存订单
	 */
	public void saveOrders(Orders orders);
}
