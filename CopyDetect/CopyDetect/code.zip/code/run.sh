java -cp bin:lib/log4j-1.2.11.jar:lib/swing-layout-1.0.3.jar:lib/IKAnalyzer3.2.0Stable.jar jaunty.copydetect.MainJFrame
