package jaunty.copydetect;

/**
 * 计算后验概率
 * @author hellojinjie
 * @date May 9, 2010 10:30:11 PM
 */
public class PosterioriProbabilityMeasure {
	
}
